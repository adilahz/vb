import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:vb2/usersModel.dart';
import 'package:http/http.dart' as http;
import 'api.dart';

class Profile extends StatefulWidget {
  @override
  _ProfileState createState() => _ProfileState();
}

class _ProfileState extends State<Profile> {
  var loading = false;
  final list = new List<userModel>();
  _lihatUser() async {
    list.clear();
    setState(() {
      loading=true;
    });

    final response = await http.get(BaseUrl.userData);
    if (response.contentLength==2){
    }else{
      final data = jsonDecode(response.body);
      data.forEach((api){
        final ab = new userModel(api['agentId'],api ['agentName'],api ['agentCode']);
        list.add(ab);
      });
      setState(() {
        loading=false;
      });
    }
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    _lihatUser();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body:  loading
          ? Center(child: CircularProgressIndicator())
          : ListView.builder(
          itemCount: list.length,
          itemBuilder: (context,i){
            final x = list[i];
            return Container(
              padding: EdgeInsets.all(50.0),
              child: Column(
                children: <Widget>[
                  new Padding(padding: new EdgeInsets.all(10.0),),
                  Text("Agent Name"),
                  new Padding(padding: new EdgeInsets.all(5.0),),
                  Text(x.agentName),
                  new Padding(padding: new EdgeInsets.all(10.0),),
                  Text("Agent Code"),
                  new Padding(padding: new EdgeInsets.all(5.0),),
                  Text(x.agentCode),
                  new Padding(padding: new EdgeInsets.all(10.0),),
                  Text("Agent Id"),
                  new Padding(padding: new EdgeInsets.all(5.0),),
                  Text(x.agentId),

                  new Padding(padding: new EdgeInsets.all(30.0),),
                  new RaisedButton(
                    child: new Text("Update"),
                    color: Colors.lightBlueAccent,
                    onPressed: () {
                    },
                  )

                ],
              ),
            );
          }
      ),
    );
  }
}

