class BaseUrl{
  static String login = "http://10.0.2.2/Shazay_vb/login.php";
  static String register = "http://10.0.2.2/Shazay_vb/register.php";
  static String activity = "http://10.0.2.2/Shazay_vb/activity.php";
  static String viewActivity = "http://10.0.2.2/Shazay_vb/getActivity.php";
  static String userData = "http://10.0.2.2/Shazay_vb/userData.php?username=";
  static String userData2 = "http://10.0.2.2/Shazay_vb/userData2.php";
}