class userModel{
  final String agentName;
  final String agentCode;
  final String agentId;


  userModel( this.agentId, this.agentName, this.agentCode);

}