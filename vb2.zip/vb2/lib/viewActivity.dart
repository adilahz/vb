import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:vb2/datePicker.dart';
import 'api.dart';
import 'datePicker.dart';
import 'package:intl/intl.dart';


class viewActivity extends StatefulWidget {
  @override
  _viewActivityState createState() => new _viewActivityState();
}

class _viewActivityState extends State<viewActivity> {

  String presso, phoneCall, newName, userId;
  final _key = new GlobalKey<FormState>();

  getPref() async {
    SharedPreferences preferences = await SharedPreferences.getInstance();
    setState(() {
      userId = preferences.getString("id");
    });
  }

  check() {
    final form = _key.currentState;
    if (form.validate()) {
      form.save();
      submit();
    }
  }

  submit() async {
    final response = await http.post(BaseUrl.viewActivity,
        body: {
          "presso": presso,
          "phoneCall": phoneCall,
          "newName": newName,
          "date": "$date",
          "userId": userId
        }

    );
    final data = jsonDecode(response.body);
    int value = data['value'];
    String message = data ['message'];
    if (value == 1) {
      print(message);
      setState(() {
        Navigator.pop(context);
      });
    }
    else {
      print(message);
    }
  }

  String datePicked, labelText;
  DateTime date = new DateTime.now();
  final TextStyle valueStyle = TextStyle(fontSize: 16.0);

  Future<Null> _selectedDate(BuildContext context) async {
    final DateTime picked = await showDatePicker(
        context: context,
        initialDate: date,
        firstDate: DateTime(2018),
        lastDate: DateTime(2060));

    if (picked != null && picked != date) {
      setState(() {
        date = picked;
        datePicked = new DateFormat.yMd().format(date);
      });
    }
    else {

    }
  }

  @override
  void initState() {
    super.initState();
    getPref();
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: new Container(
        padding: const EdgeInsets.all(30.0),
        child: Form(
          key: _key,
          child: new Column(
            children: <Widget>[
              new Padding(padding: new EdgeInsets.all(10.0),),

              DateDropDown(
                labelText: "Date",
                valueText: new DateFormat.yMd().format(date),
                valueStyle: valueStyle,
                onPressed: () {
                  _selectedDate(context);
                },
              ),
              //new Padding(padding: new EdgeInsets.all(10.0),),

              new Row(
                children: <Widget>[
                  new Padding(padding: new EdgeInsets.all(20.0),),
                  new Icon(
                      Icons.call,
                      color: Colors.black87,
                      size: 40.0),
                  new Padding(padding: new EdgeInsets.all(40.0),),
                  new IconButton(icon: new Icon(Icons.remove_circle)),
                  //,
                  new Flexible(
                    child: new TextFormField(
                      onSaved: (e) => phoneCall = e,
                      keyboardType: TextInputType.number,


                    ),
                  ),
                  new Container(
                    //margin: new EdgeInsets.symmetric(horizontal: 15.0),
                    child: new IconButton(icon: new Icon(Icons.add_circle)),
                  ),
                  //new Padding(padding: new EdgeInsets.all(10.0),),
                ],
              ),
              new Padding(padding: new EdgeInsets.all(5.0),),

              new Row(
                children: <Widget>[
                  new Padding(padding: new EdgeInsets.all(20.0),),
                  new Icon(
                      Icons.description,
                      color: Colors.black87,
                      size: 40.0),
                  new Padding(padding: new EdgeInsets.all(40.0),),
                  new IconButton(icon: new Icon(Icons.remove_circle)),
                  //,
                  new Flexible(
                    child: new TextFormField(
                      keyboardType: TextInputType.number,
                      onSaved: (e) => presso = e,
                    ),
                  ),
                  new Container(
                    //margin: new EdgeInsets.symmetric(horizontal: 15.0),
                    child: new IconButton(icon: new Icon(Icons.add_circle)),
                  ),
                  //new Padding(padding: new EdgeInsets.all(10.0),),
                ],
              ),
              new Padding(padding: new EdgeInsets.all(5.0),),

              new Row(
                children: <Widget>[
                  new Padding(padding: new EdgeInsets.all(20.0),),
                  new Icon(
                      Icons.contacts,
                      color: Colors.black87,
                      size: 40.0),
                  new Padding(padding: new EdgeInsets.all(40.0),),
                  new IconButton(icon: new Icon(Icons.remove_circle)),
                  //,
                  new Flexible(
                    child: new TextFormField(
                      keyboardType: TextInputType.number,
                      onSaved: (e) => newName = e,
                    ),
                  ),
                  new Container(
                    //margin: new EdgeInsets.symmetric(horizontal: 15.0),
                    child: new IconButton(icon: new Icon(Icons.add_circle)),
                  ),
                  //new Padding(padding: new EdgeInsets.all(5.0),),
                ],
              ),







              Center(
                child: Padding(
                  padding: const EdgeInsets.all(30.0),
                  child: new Column(
                    children: <Widget>[
                      new RaisedButton(
                        child: new Text("Submit"),
                        color: Colors.lightBlueAccent,
                        onPressed: () {
                          check();
                        },
                      )
                    ],
                  ),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}
